﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HangmanTests {
    [TestClass]
    public class HangmanTests {
        [TestMethod]
        public void TestMethod1() {
        }
    }
}
